﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Library_Managment_System
{
    public partial class List_of_borrowed_books : Form
    {
        public List_of_borrowed_books()
        {
            InitializeComponent();
        }

        public string conString = "Data Source=DESKTOP-284ALNG;Initial Catalog=LibraryDataBase;Integrated Security=True";

        private void button1_Click(object sender, EventArgs e)
        {
            Borrower_options b = new Borrower_options();
            b.Show();
            Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(textBox1.Text, out int borrowerID))
                {
                    MessageBox.Show("Please enter a valid borrower ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                SqlConnection con = new SqlConnection(conString);
                con.Open();

                if (con.State == System.Data.ConnectionState.Open) // check the connection is open
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;

                    cmd.CommandText = "select * from Issued_books where Borrower_ID = @BorrowerID and state = 1";
                    cmd.Parameters.AddWithValue("@BorrowerID", borrowerID);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable ds = new DataTable();
                    da.Fill(ds);
                    dataGridView1.DataSource = ds;
                }
                else
                {
                    MessageBox.Show("please open the connection !");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Enter a correct type of this input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception)
            {
                MessageBox.Show("Wrong Entery", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
