﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Diagnostics;

namespace Library_Managment_System
{
    public partial class create_account : Form
    {
        public create_account()
        {
            InitializeComponent();
        }

        public string conString = "Data Source=DESKTOP-284ALNG;Initial Catalog=LibraryDataBase;Integrated Security=True";

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                // intilize variable
                string name = textBox1.Text;
                int Id = Convert.ToInt32(textBox2.Text);
                string email = textBox3.Text;
                string password = textBox4.Text;
                string Type = comboBox1.Text;
                string q = ""; // qeury

                // start connection
                SqlConnection con = new SqlConnection(conString);
                con.Open();


                if (con.State == System.Data.ConnectionState.Open)   // check the connection is open
                {
                    if (comboBox1.SelectedItem != null)
                    {


                        // enter login detailes in the database
                        q = "insert into Login(User_Name,Password)values('" + email.ToString() + "','" + password.ToString() + "')";
                        SqlCommand cmd = new SqlCommand(q, con);
                        cmd.ExecuteNonQuery(); // go to sql and execute the query

                        // check if the register is Librarian or Borrower ,then insert the values in the table
                        switch (Type)
                        {
                            case "Librarian":
                                q = "insert into Librarian(Name,Email,ID)values('" + name.ToString() + "','" + email.ToString() + "','" + Id.ToString() + "')";
                                break;
                            case "Borrower":
                                q = "insert into Borrower(Name,Email,ID)values('" + name.ToString() + "','" + email.ToString() + "','" + Id.ToString() + "')";
                                break;

                        }

                        // execute the query
                        cmd = new SqlCommand(q, con);
                        cmd.ExecuteNonQuery();
                        // msg 
                        MessageBox.Show("account made successfully..!");

                    }
                    else
                    {
                        MessageBox.Show("please select a membership type from the combobox !");
                    }
                }
                else
                {
                    MessageBox.Show("please open the connection !");
                }


            } // End try 
            catch (FormatException )
            {
                MessageBox.Show("Enter a correct type of this input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception )
            {
                MessageBox.Show("Wrong Entery", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            login_form l = new login_form();
            l.Show();
            Visible = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    } // End class
}
