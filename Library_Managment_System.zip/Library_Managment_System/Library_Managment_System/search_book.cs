﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Library_Managment_System
{
    public partial class search_book : Form
    {
        public search_book()
        {
            InitializeComponent();
        }

        public string conString = "Data Source=DESKTOP-284ALNG;Initial Catalog=LibraryDataBase;Integrated Security=True";
        private void button2_Click(object sender, EventArgs e)
        {
            Borrower_options b = new Borrower_options();
            b.Show();
            Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try { 
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            string book_ISBN = textBox1.Text;

            if (con.State == System.Data.ConnectionState.Open) // check the connection is open
            {
                    cmd.CommandText = "select * from Books where ISBN = '" + book_ISBN.ToString() + "' ";

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable ds = new DataTable();
                    da.Fill(ds);

                    // to display the query
                    dataGridView1.DataSource = ds;



                }
            else
            {
                MessageBox.Show("please open the connection !");
            }
        } // End try 
            catch (FormatException )
            {
                MessageBox.Show("Enter a correct type of this input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception )
            {
                MessageBox.Show("Wrong Entery", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        } // End 

        private void search_book_Load(object sender, EventArgs e)
        {

        }
    }
}
