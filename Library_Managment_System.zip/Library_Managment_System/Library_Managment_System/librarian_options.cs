﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Managment_System
{
    public partial class librarian_options : Form
    {
        public librarian_options()
        {
            InitializeComponent();
        }


        private void button3_Click(object sender, EventArgs e) // Reserve books 

        {
            Reserved_books v = new Reserved_books();
            v.Show();
            Visible = false;
        }

       

        private void button6_Click(object sender, EventArgs e) // Return book
 
        {
            Return_book r = new Return_book();
            r.Show();
            Visible = false;
        }

        private void button1_Click(object sender, EventArgs e) // Add book
        {
            Add_Book a = new Add_Book();
            a.Show();
            Visible = false;
        }

        private void button2_Click(object sender, EventArgs e) // sign out
        {
            login_form l = new login_form();
            l.Show();
            Visible = false;
        }

        private void button4_Click(object sender, EventArgs e) // Display book
        {
            display_box d = new display_box();
            d.Show();
            Visible = false;
        }
    }
}
