﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Xml.Schema;
using System.Globalization;
using System.Diagnostics.Eventing.Reader;

namespace Library_Managment_System
{
    public partial class Reserved_books : Form
    {
        public Reserved_books()
        {
            InitializeComponent();
        }

        public string conString = "Data Source=DESKTOP-284ALNG;Initial Catalog=LibraryDataBase;Integrated Security=True";

        private void button2_Click(object sender, EventArgs e)
        {
            librarian_options l = new librarian_options();
            l.Show();
            Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string bookISBN = textBox1.Text;
                int borrowerID = Convert.ToInt32(textBox2.Text);

                // Open the connection
                using (SqlConnection con = new SqlConnection(conString))
                {
                    con.Open();

                    // Check if the borrower is allowed to borrow books
                    using (var cmd = new SqlCommand())
                    {
                        cmd.Connection = con;
                        cmd.CommandText = "SELECT Membership FROM Borrower WHERE ID = @BorrowerID";
                        cmd.Parameters.AddWithValue("@BorrowerID", borrowerID);

                        string membership = Convert.ToString(cmd.ExecuteScalar());

                        if (membership == "1") // membership is canceled
                        {
                            MessageBox.Show("The borrower's membership is canceled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    // Check if the book is available for reservation
                    using (var cmd = new SqlCommand())
                    {
                        cmd.Connection = con;
                        cmd.CommandText = "SELECT COUNT(*) FROM Issued_books WHERE Book_ISBN = @BookISBN AND State = 1";
                        cmd.Parameters.AddWithValue("@BookISBN", bookISBN);

                        int count = (int)cmd.ExecuteScalar();

                        if (count > 0)
                        {
                            MessageBox.Show("The book is already reserved or issued.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                    string insertStatement = "INSERT INTO Issued_books (Book_ISBN, Book_Tittle, Borrower_ID, Borrower_Name,Issue_Date, state) VALUES (@BookISBN, (SELECT Tittle FROM Books WHERE ISBN = @BookISBN), @BorrowerID, (SELECT Name FROM Borrower WHERE ID = @BorrowerID),GETDATE(), 1)";

                   
                    using (var cmd = new SqlCommand(insertStatement))
                    {
                        cmd.Connection = con;

                        // Add the parameters to the command
                        cmd.Parameters.AddWithValue("@BookISBN", bookISBN);
                        cmd.Parameters.AddWithValue("@BorrowerID", borrowerID);

                        // Execute the command
                        cmd.ExecuteNonQuery();
                    }

                    // Display a success message
                    MessageBox.Show("The book has been reserved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Enter a correct type of this input.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
