﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Library_Managment_System
{
    public partial class login_form : Form
    {
        public login_form()
        {
            InitializeComponent();
        }

        public string conString = "Data Source=DESKTOP-284ALNG;Initial Catalog=LibraryDataBase;Integrated Security=True";

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string username = textBox1.Text;
                string password = textBox2.Text;

                SqlConnection con = new SqlConnection(conString);
                con.Open();


                if (con.State == System.Data.ConnectionState.Open) // check the connection is open
                {
                    // do the qeury
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;

                    cmd.CommandText = "select * from Login where User_Name = '" + username.ToString() + "' and Password = '" + password.ToString() + "' ";
                    
                    // fill Datatset in the visual basic
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    // check if the login and username in database
                    if (ds.Tables[0].Rows.Count != 0)
                    {
                        Visible = false;

                        cmd.CommandText = "select Email from Librarian where Email = '" + username.ToString() + "' ";
                        SqlDataAdapter da2 = new SqlDataAdapter(cmd);
                        DataSet ds2 = new DataSet();
                        da2.Fill(ds2);

                        if (ds2.Tables[0].Rows.Count != 0)
                        {
                            librarian_options l = new librarian_options();
                            l.Show();
                        }
                        else
                        {
                            Borrower_options b = new Borrower_options();
                            b.Show();
                        }


                    }
                    else
                    {

                        MessageBox.Show("invalid username or password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    con.Close();
                } // End if connection statement
                else
                {
                    MessageBox.Show("please open the connection !");
                }
            } // End try 
            catch (FormatException )
            {
                MessageBox.Show("Enter a correct type of this input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception )
            {
                MessageBox.Show("Wrong Entery", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }





        } // End button

        private void button2_Click(object sender, EventArgs e)
        {
            create_account c = new create_account();
            c.Show();
            Visible = false;
        }
    }
}
