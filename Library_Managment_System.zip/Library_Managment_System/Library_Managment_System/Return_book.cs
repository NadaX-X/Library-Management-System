﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

namespace Library_Managment_System
{
    public partial class Return_book : Form
    {
        public Return_book()
        {
            InitializeComponent();
        }

        public string conString = "Data Source=DESKTOP-284ALNG;Initial Catalog=LibraryDataBase;Integrated Security=True";

        private void button2_Click(object sender, EventArgs e)
        {
            librarian_options l = new librarian_options();
            l.Show();
            Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {

                // Get the book ISBN and borrower ID
                string bookISBN = textBox1.Text;
                int borrowerID = Convert.ToInt32(textBox2.Text);

                // Calculate the fine, if any
                int fine = 0;
                DateTime currentDate = DateTime.Now;
                DateTime issueDate = GetIssueDate(bookISBN);
                DateTime dueDate = issueDate.AddDays(30);

                if (currentDate > dueDate)
                {

                using (SqlConnection con = new SqlConnection(conString))
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("SELECT counter FROM Cancel_membership WHERE Borrower_ID = @BorrowerID ", con);

                    cmd.Parameters.AddWithValue("@BorrowerID", borrowerID);

                    int counter = (int)cmd.ExecuteScalar();

                     counter++;
                    SqlCommand cmd8 = new SqlCommand("UPDATE Cancel_membership SET counter = @counter", con);
                    cmd.Parameters.AddWithValue("@counter", counter);
                    cmd.ExecuteNonQuery();

                }

                    int daysOverdue = (currentDate - dueDate).Days;
                

                    // Calculate fine for up to 30 days
                    if (daysOverdue <= 30)
                    {
                        fine = daysOverdue * 10;
                    }

                    // Handle late returns beyond 30 days
                    else
                    {
                        // Book is considered lost, charge twice the cost of the book
                        fine = 2 * GetBookCost(bookISBN);

                        // Update the borrower's membership status to 'Canceled'
                        using (SqlConnection con = new SqlConnection(conString))
                        {
                            con.Open();

                            SqlCommand cmd = new SqlCommand("UPDATE Borrower SET Membership = 1 WHERE Borrower_ID = @BorrowerID", con);
                            cmd.Parameters.AddWithValue("@BorrowerID", borrowerID);
                            cmd.ExecuteNonQuery();

                            con.Close();
                        }

                        // Display a message indicating lost book and membership cancellation
                        MessageBox.Show("Book is State lost.  thr borrower must pay twice the cost of the book. his membership has been canceled due to excessive late returns.", "Lost Book and Membership Cancellation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }

                // Update the Issued_books table
                using (SqlConnection con = new SqlConnection(conString))
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("UPDATE Issued_books SET Return_Date = @ReturnDate, fine = @Fine, State = 0 WHERE Book_ISBN = @BookISBN", con);
                    cmd.Parameters.AddWithValue("@ReturnDate", currentDate);
                    cmd.Parameters.AddWithValue("@Fine", fine);
                    cmd.Parameters.AddWithValue("@BookISBN", bookISBN);

                    cmd.ExecuteNonQuery();

                    con.Close();
                }

            // Update the Borrower table if the borrower has more than three late returns
            UpdateBorrowerMembership(borrowerID);

                // Display a success message
                MessageBox.Show("Book returned successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            private DateTime GetIssueDate(string bookISBN)
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("SELECT Issue_Date FROM Issued_books WHERE Book_ISBN = @BookISBN", con);
                    cmd.Parameters.AddWithValue("@BookISBN", bookISBN);

                    DateTime issueDate = (DateTime)cmd.ExecuteScalar();

                    con.Close();

                    return issueDate;
                }
            }

            private int GetBookCost(string bookISBN)
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("SELECT price FROM Books WHERE Book_ISBN = @BookISBN", con);
                    cmd.Parameters.AddWithValue("@BookISBN", bookISBN);

                    int bookCost = (int)cmd.ExecuteScalar();

                    con.Close();

                    return bookCost;
                }
            }

        private void UpdateBorrowerMembership(int borrowerID)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("SELECT counter FROM Cancel_membership WHERE Borrower_ID = @BorrowerID ", con);
                cmd.Parameters.AddWithValue("@BorrowerID", borrowerID);
                int? counter = (int?)cmd.ExecuteScalar();

                if (counter != null && counter > 4)
                {
                    cmd.CommandText = "UPDATE Borrower SET Membership = 0 WHERE Borrower_ID = @BorrowerID";
                    cmd.ExecuteNonQuery();

                    cmd.CommandText = "UPDATE Cancel_membership SET counter = counter + 1 WHERE Borrower_ID = @BorrowerID";
                    cmd.ExecuteNonQuery();
                }

                con.Close();
            }
        }
    }
}
