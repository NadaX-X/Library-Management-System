﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Library_Managment_System
{
    public partial class Add_Book : Form
    {
        public Add_Book()
        {
            InitializeComponent();
        }

        public string conString = "Data Source=DESKTOP-284ALNG;Initial Catalog=LibraryDataBase;Integrated Security=True";


        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string ISBN = textBox1.Text;
                string Title = textBox2.Text;
                string Author = textBox3.Text;
                string Edition = textBox4.Text;
                float Price = (float)Convert.ToDouble(textBox5.Text);


                SqlConnection con = new SqlConnection(conString);
                con.Open();


                if (con.State == System.Data.ConnectionState.Open) // check the connection is open
                {

                    string q = "insert into Books(Tittle,Auther,ISBN,Edition,price)values('" + Title.ToString() + "','" + Author.ToString() + "','" + ISBN.ToString() + "','" + Edition.ToString() + "','" + Price.ToString() + "')";
                    
                    SqlCommand cmd = new SqlCommand(q, con);
                
                    cmd.ExecuteNonQuery();
                    
                    MessageBox.Show("You added a new Book !");

                } // End if connection statement

                else
                {
                    MessageBox.Show("please open the connection !");
                }
            }
            catch (FormatException)
            {

                MessageBox.Show("Enter a correct type of this input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception)
            {

                MessageBox.Show("Wrong Entery", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            librarian_options l = new librarian_options();
            l.Show();
            Visible = false;
        }
    }
}
