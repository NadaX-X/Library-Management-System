﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Library_Managment_System
{
    public partial class display_box : Form
    {
        public display_box()
        {
            InitializeComponent();
        }

        public string conString = "Data Source=DESKTOP-284ALNG;Initial Catalog=LibraryDataBase;Integrated Security=True";
        private void button1_Click(object sender, EventArgs e)
        {
            librarian_options l = new librarian_options();
            l.Show();
            Visible = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            {
                
                SqlDataAdapter da = null;


                // Set the command text based on the selected index
                switch (comboBox1.SelectedIndex)
                {
                    case 0: // All books
                            //   cmd.CommandText = "SELECT  b.* ,i.State  FROM Books b , Issued_books i  ORDER BY Tittle ASC";
                        cmd.CommandText = "SELECT b.*, i.state FROM Books b INNER JOIN Issued_books i ON b.ISBN = i.Book_ISBN ORDER BY b.Tittle ASC";

                        break;
                    case 1: // Available books
                        cmd.CommandText = "SELECT * FROM Books WHERE ISBN NOT IN (SELECT Book_ISBN FROM Issued_books WHERE State = 1) ORDER BY Tittle ASC";
                       
                        break;
                    case 2: // Reserved books
                         cmd.CommandText = "SELECT * FROM Books WHERE ISBN IN (SELECT Book_ISBN FROM Issued_books WHERE State = 1) ORDER BY Tittle ASC";
                        break;
                }

                // Fill a DataTable with the results of the query
                DataTable ds = new DataTable();
                da = new SqlDataAdapter(cmd);
                da.Fill(ds);

                // Bind the DataTable to the DataGridView control
                dataGridView1.DataSource = ds;
            }
        }
    }
    } 
